package solver;

public class SolutionFoundException extends Exception{

}
