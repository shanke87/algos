The runnable jar have created from the source code in windows environment. Invoking this would give the started the GUI solver.
Extract the contents to a folder and change to the shankar folder.
>javac solver\*.java 
>java solver.SudokuGrid

