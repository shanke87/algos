package solver;

public class BoardImage {
	public int r, c, box, cell;
}
